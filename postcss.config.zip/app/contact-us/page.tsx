import React from 'react';
import CommingSoon from '../component/Common/CommingSoon';
import Contact from '../component/Contact/Contact';

const page = () => {
    return (
        <div className=' container mx-auto'>
            <Contact/>
        </div>
    );
};

export default page;