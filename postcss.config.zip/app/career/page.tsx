import React from 'react';
import CommingSoon from '../component/Common/CommingSoon';

const page = () => {
    return (
        <div>
            <CommingSoon/>
        </div>
    );
};

export default page;